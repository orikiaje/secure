<?php
// by Anoxyty
$location = 'https://www.wellsfargo.com/'; // where to send bad people


$range_low = ip2long("208.80.192.0");
$range_high = ip2long("208.80.207.255");
$range_low = ip2long("69.25.48.0");
$range_high = ip2long("69.25.62.255");
$range_low = ip2long("194.52.68.0");
$range_high = ip2long("194.52.68.255");
$range_low = ip2long("139.59.196.0");
$range_high = ip2long("139.59.201.162");
$range_low = ip2long("194.72.238.0");
$range_high = ip2long("194.72.238.255");
$range_low = ip2long("83.138.182.72");
$range_high = ip2long("83.138.182.79");
$range_low = ip2long("83.138.189.96");
$range_high = ip2long("83.138.189.103");
$range_low = ip2long("81.91.240.0");
$range_high = ip2long("81.91.255.255");
$range_low = ip2long("89.36.24.0");
$range_high = ip2long("89.36.31.255");
$range_low = ip2long("83.222.232.216");
$range_high = ip2long("83.222.232.218");
$range_low = ip2long("184.172.0.0");
$range_high = ip2long("184.173.255.255");

#  KASPERSKY IP RANGES

$range_low = ip2long("195.170.248.0");
$range_high = ip2long("195.170.248.255");
$range_low = ip2long("212.5.107.128");
$range_high = ip2long("212.5.107.255");
$range_low = ip2long("212.5.80.0");
$range_high = ip2long("212.5.80.63");
$range_low = ip2long("212.5.110.0");
$range_high = ip2long("212.5.110.255");
$range_low = ip2long("80.239.144.72");
$range_high = ip2long("80.239.144.79");
$range_low = ip2long("80.23.53.208");
$range_high = ip2long("80.23.53.215");
$range_low = ip2long("81.176.69.64");
$range_high = ip2long("81.176.69.127");
$range_low = ip2long("80.239.156.192");
$range_high = ip2long("80.239.156.207");
$range_low = ip2long("213.247.248.80");
$range_high = ip2long("213.247.248.83");
$range_low = ip2long("213.247.248.112");
$range_high = ip2long("213.247.248.119");
$range_low = ip2long("212.58.46.56");
$range_high = ip2long("212.58.46.63");
$range_low = ip2long("91.103.64.0");
$range_high = ip2long("91.103.71.255");
$range_low = ip2long("91.103.64.0");
$range_high = ip2long("91.103.67.255");
$range_low = ip2long("212.178.99.152");
$range_high = ip2long("212.178.99.159");
$range_low = ip2long("212.47.219.80");
$range_high = ip2long("212.47.219.95");
$range_low = ip2long("195.161.114.0");
$range_high = ip2long("195.161.114.255");
$range_low = ip2long("91.103.68.0");
$range_high = ip2long("91.103.71.255");
$range_low = ip2long("77.74.176.0");
$range_high = ip2long("77.74.183.255");
$range_low = ip2long("77.74.176.0");
$range_high = ip2long("77.74.179.255");
$range_low = ip2long("77.74.180.0");
$range_high = ip2long("77.74.183.255");
$range_low = ip2long("195.222.17.32");
$range_high = ip2long("195.222.17.63");
$range_low = ip2long("195.27.181.0");
$range_high = ip2long("195.27.181.255");
$range_low = ip2long("88.58.91.48");
$range_high = ip2long("88.58.91.55");
$range_low = ip2long("93.159.224.0");
$range_high = ip2long("93.159.231.255");
$range_low = ip2long("213.0.56.232");
$range_high = ip2long("213.0.56.239");
$range_low = ip2long("213.0.107.144");
$range_high = ip2long("213.0.107.151");
$range_low = ip2long("80.239.197.96");
$range_high = ip2long("80.239.197.127");
$range_low = ip2long("94.228.184.16");
$range_high = ip2long("94.228.184.23");
$range_low = ip2long("93.104.193.160");
$range_high = ip2long("93.104.193.191");
$range_low = ip2long("62.213.110.0");
$range_high = ip2long("62.213.110.63");
$range_low = ip2long("92.33.3.64");
$range_high = ip2long("92.33.3.95");
$range_low = ip2long("92.33.3.96");
$range_high = ip2long("92.33.3.127");
$range_low = ip2long("82.98.75.128");
$range_high = ip2long("82.98.75.191");
$range_low = ip2long("212.5.89.0");
$range_high = ip2long("212.5.89.255");
$range_low = ip2long("87.118.220.168");
$range_high = ip2long("87.118.220.171");
$range_low = ip2long("62.213.110.128");
$range_high = ip2long("62.213.110.191");
$range_low = ip2long("94.228.185.80");
$range_high = ip2long("94.228.185.95");
$range_low = ip2long("85.18.238.56");
$range_high = ip2long("85.18.238.59");
$range_low = ip2long("82.98.110.160");
$range_high = ip2long("82.98.110.191");
$range_low = ip2long("93.104.242.128");
$range_high = ip2long("93.104.242.159");
$range_low = ip2long("93.104.242.160");
$range_high = ip2long("93.104.242.191");
$range_low = ip2long("80.239.174.32");
$range_high = ip2long("80.239.174.63");
$range_low = ip2long("82.98.105.32");
$range_high = ip2long("82.98.105.63");
$range_low = ip2long("212.19.32.64");
$range_high = ip2long("212.19.32.159");
$range_low = ip2long("87.213.24.40");
$range_high = ip2long("87.213.24.43");
$range_low = ip2long("87.213.45.168");
$range_high = ip2long("87.213.45.175");
$range_low = ip2long("93.104.230.192");
$range_high = ip2long("93.104.230.255");
$range_low = ip2long("88.217.237.0");
$range_high = ip2long("88.217.237.255");
$range_low = ip2long("80.239.170.128");
$range_high = ip2long("80.239.170.191");
$range_low = ip2long("195.27.252.0");
$range_high = ip2long("195.27.252.127");
$range_low = ip2long("80.239.169.128");
$range_high = ip2long("80.239.169.159");
$range_low = ip2long("213.155.151.32");
$range_high = ip2long("213.155.151.63");
$range_low = ip2long("212.65.69.56");
$range_high = ip2long("212.65.69.63");
$range_low = ip2long("212.65.93.24");
$range_high = ip2long("212.65.93.31");
$range_low = ip2long("212.65.82.48");
$range_high = ip2long("212.65.82.55");
$range_low = ip2long("46.229.18.64");
$range_high = ip2long("46.229.18.95");
$range_low = ip2long("212.170.112.192");
$range_high = ip2long("212.170.112.199");
$range_low = ip2long("2.228.23.32");
$range_high = ip2long("2.228.23.39");
$range_low = ip2long("82.98.75.40");
$range_high = ip2long("82.98.75.47");
$range_low = ip2long("82.98.74.8");
$range_high = ip2long("82.98.74.15");
$range_low = ip2long("193.45.6.0");
$range_high = ip2long("193.45.6.31");
$range_low = ip2long("93.159.224.0");
$range_high = ip2long("93.159.227.255");
$range_low = ip2long("93.159.228.0");
$range_high = ip2long("93.159.228.0");
$range_low = ip2long("93.159.230.0");
$range_high = ip2long("93.159.231.255");
$range_low = ip2long("2.228.172.192");
$range_high = ip2long("2.228.172.199");
$range_low = ip2long("81.19.104.0");
$range_high = ip2long("81.19.104.255");
 
# OPENDNS IP RANGES
 
$range_low = ip2long("65.199.111.184");
$range_high = ip2long("65.199.111.191");
$range_low = ip2long("63.80.66.32");
$range_high = ip2long("63.80.66.63");
$range_low = ip2long("65.203.37.40");
$range_high = ip2long("65.203.37.47");
$range_low = ip2long("65.222.158.80");
$range_high = ip2long("65.222.158.87");
$range_low = ip2long("208.67.216.0");
$range_high = ip2long("208.67.223.255");
$range_low = ip2long("208.69.32.0");
$range_high = ip2long("208.69.39.255");
$range_low = ip2long("67.215.64.0");
$range_high = ip2long("67.215.95.255");
$range_low = ip2long("63.118.61.32");
$range_high = ip2long("63.118.61.63");
$range_low = ip2long("65.204.147.0");
$range_high = ip2long("65.204.147.7");
$range_low = ip2long("212.13.198.240");
$range_high = ip2long("212.13.198.255");

#  INTERNET SYSTEMS CONSORTIUM IP RANGES PHISHTANK

$range_low = ip2long("149.20.0.0");
$range_high = ip2long("149.20.255.255");
$range_low = ip2long("192.5.4.0");
$range_high = ip2long("192.5.5.255");
$range_low = ip2long("204.152.184.0");
$range_high = ip2long("204.152.191.255");
$range_low = ip2long("146.112.225.0");
$range_high = ip2long("146.112.225.255");

#  BITDEFENDER IP RANGES

$range_low = ip2long("91.199.104.0");
$range_high = ip2long("91.199.104.255");
$range_low = ip2long("62.153.200.240");
$range_high = ip2long("62.153.200.247");
$range_low = ip2long("195.210.4.0");
$range_high = ip2long("195.210.5.255");
$range_low = ip2long("37.59.67.144");
$range_high = ip2long("37.59.67.159");
$range_low = ip2long("37.58.119.200");
$range_high = ip2long("37.58.119.207");
$range_low = ip2long("81.161.59.0");
$range_high = ip2long("81.161.59.255");
$range_low = ip2long("5.10.82.120");
$range_high = ip2long("5.10.82.123");
$range_low = ip2long("159.253.146.200");
$range_high = ip2long("159.253.146.207");

# SURFRIGHT IP RANGES

$range_low = ip2long("87.249.110.176");
$range_high = ip2long("87.249.110.191");

# FORTINET TECHNOLOGIES IP RANGES
 
$range_low = ip2long("204.101.161.0");
$range_high = ip2long("204.101.161.255");
$range_low = ip2long("173.212.140.0");
$range_high = ip2long("173.212.140.255");
$range_low = ip2long("69.90.198.48");
$range_high = ip2long("69.90.198.63");
$range_low = ip2long("69.20.231.224");
$range_high = ip2long("69.20.231.239");
$range_low = ip2long("204.50.6.64");
$range_high = ip2long("204.50.6.95");
$range_low = ip2long("62.209.40.64");
$range_high = ip2long("62.209.40.79");
$range_low = ip2long("217.169.59.64");
$range_high = ip2long("217.169.59.71");
$range_low = ip2long("80.85.69.32");
$range_high = ip2long("80.85.69.63");
$range_low = ip2long("212.25.23.184");
$range_high = ip2long("212.25.23.191");
$range_low = ip2long("208.91.112.0");
$range_high = ip2long("208.91.115.255");
$range_low = ip2long("96.45.32.0");
$range_high = ip2long("96.45.47.255");
$range_low = ip2long("173.243.128.0");
$range_high = ip2long("173.243.143.255");
$range_low = ip2long("66.35.16.0");
$range_high = ip2long("66.35.31.255");
 
# GOOGLE APPS IP RANGES  

$range_low = ip2long("66.101.224.0");
$range_high = ip2long("66.102.7.225"); 
$range_low = ip2long("213.157.192.0");
$range_high = ip2long("213.157.223.255"); 
$range_low = ip2long("96.31.1.0");
$range_high = ip2long("96.31.1.63"); 
$range_low = ip2long("199.192.112.0");
$range_high = ip2long("199.192.115.255");
$range_low = ip2long("206.160.135.240");
$range_high = ip2long("206.160.135.255");
$range_low = ip2long("208.21.209.0");
$range_high = ip2long("208.21.209.15");
$range_low = ip2long("108.59.80.0");
$range_high = ip2long("108.59.95.255");
$range_low = ip2long("173.255.112.0");
$range_high = ip2long("173.255.127.255");
$range_low = ip2long("8.35.192.0");
$range_high = ip2long("8.35.199.255");
$range_low = ip2long("8.35.200.0");
$range_high = ip2long("8.35.207.255");
$range_low = ip2long("8.34.216.0");
$range_high = ip2long("8.34.223.255");
$range_low = ip2long("8.34.208.0");
$range_high = ip2long("8.34.215.255");
$range_low = ip2long("199.223.232.0");
$range_high = ip2long("199.223.239.255");
$range_low = ip2long("192.158.28.0");
$range_high = ip2long("192.158.31.255");
$range_low = ip2long("66.249.83.84");
$range_low = ip2long("64.233.172.84");
$range_low = ip2long("66.249.84.4");
$range_low = ip2long("66.249.88.89");
$range_low = ip2long("66.102.7.4");
$range_low = ip2long("66.249.82.4");
$range_low = ip2long("66.249.85.89");
$range_low = ip2long("173.255.112.208");
$range_low = ip2long("66.249.83.204");
$range_low = ip2long("66.249.88.216");
$range_low = ip2long("64.233.160.0");
$range_high = ip2long("64.233.191.255");
$range_low = ip2long("66.102.0.0");
$range_high = ip2long("66.102.15.255");
$range_low = ip2long("66.249.64.0");
$range_high = ip2long("66.249.95.255");
$range_low = ip2long("72.14.192.0");
$range_high = ip2long("72.14.255.255");
$range_low = ip2long("74.125.0.0");
$range_high = ip2long("74.125.255.255");
$range_low = ip2long("209.85.128.0");
$range_high = ip2long("209.85.255.255");
$range_low = ip2long("216.239.32.0");
$range_high = ip2long("216.239.63.255");
$range_low = ip2long("213.143.10.192");
$range_high = ip2long("213.143.10.255");
$range_low = ip2long("94.198.143.0");
$range_high = ip2long("94.198.143.255");
$range_low = ip2long("35.182.0.0");
$range_high = ip2long("35.183.255.255");
$range_low = ip2long("35.184.160.13");
$range_high = ip2long("35.185.127.255");
$range_low = ip2long("35.185.128.0");
$range_high = ip2long("35.185.191.255");
$range_low = ip2long("35.185.236.230");
$range_high = ip2long("35.186.145.96");
$range_low = ip2long("35.186.145.98");
$range_high = ip2long("35.186.162.170");
$range_low = ip2long("35.186.162.172");
$range_high = ip2long("35.187.238.36");
$range_low = ip2long("35.187.238.38");
$range_high = ip2long("35.187.255.255");
$range_low = ip2long("35.188.0.0");
$range_high = ip2long("35.188.255.255");
$range_low = ip2long("64.233.160.0");
$range_high = ip2long("64.233.172.255");
$range_low = ip2long("208.87.232.0");
$range_high = ip2long("208.87.233.149");


# TOR SERVERS IP RANGES
 
$range_low = ip2long("96.47.226.16");
$range_high = ip2long("96.47.226.23");
$range_low = ip2long("74.120.15.144");
$range_high = ip2long("74.120.15.159");
$range_low = ip2long("96.44.189.96");
$range_high = ip2long("96.44.189.103");
 
# AMAZON IP RANGES
 
$range_low = ip2long("54.219.0.0");
$range_high = ip2long("54.219.255.255");
$range_low = ip2long("54.193.0.0");
$range_high = ip2long("54.193.255.255");
$range_low = ip2long("204.236.128.0");
$range_high = ip2long("204.236.255.255");
$range_low = ip2long("54.242.0.0");
$range_high = ip2long("54.243.255.255");
$range_low = ip2long("107.20.0.0");
$range_high = ip2long("107.23.255.255");
$range_low = ip2long("216.182.224.0");
$range_high = ip2long("216.182.239.255");
$range_low = ip2long("50.16.0.0");
$range_high = ip2long("50.19.255.255");
$range_low = ip2long("72.44.32.0");
$range_high = ip2long("72.44.63.255");
$range_low = ip2long("184.72.0.0");
$range_high = ip2long("184.73.255.255");
$range_low = ip2long("67.202.0.0");
$range_high = ip2long("67.202.63.255");
$range_low = ip2long("75.101.128.0");
$range_high = ip2long("75.101.255.255");
$range_low = ip2long("174.129.0.0");
$range_high = ip2long("174.129.255.255");
$range_low = ip2long("23.20.0.0");
$range_high = ip2long("23.23.255.255");
$range_low = ip2long("54.248.0.0");
$range_high = ip2long("54.249.255.255");
$range_low = ip2long("54.253.0.0");
$range_high = ip2long("54.253.255.255");
$range_low = ip2long("54.247.0.0");
$range_high = ip2long("54.247.255.255");
$range_low = ip2long("54.233.0.0");
$range_high = ip2long("54.233.255.255");
$range_low = ip2long("54.226.0.0");
$range_high = ip2long("54.227.255.255");
$range_low = ip2long("54.230.0.0");
$range_high = ip2long("54.231.255.255");
$range_low = ip2long("54.234.0.0");
$range_high = ip2long("54.235.255.255");
$range_low = ip2long("54.232.0.0");
$range_high = ip2long("54.232.255.255");
$range_low = ip2long("54.236.0.0");
$range_high = ip2long("54.237.255.255");
$range_low = ip2long("54.252.0.0");
$range_high = ip2long("54.252.255.255");
$range_low = ip2long("54.251.0.0");
$range_high = ip2long("54.251.255.255");
$range_low = ip2long("54.238.0.0");
$range_high = ip2long("54.238.255.255");
$range_low = ip2long("54.228.0.0");
$range_high = ip2long("54.229.255.255");
$range_low = ip2long("54.208.0.0");
$range_high = ip2long("54.209.255.255");
$range_low = ip2long("54.210.0.0");
$range_high = ip2long("54.211.255.255");
$range_low = ip2long("54.216.0.0");
$range_high = ip2long("54.217.255.255");
$range_low = ip2long("54.220.0.0");
$range_high = ip2long("54.220.255.255");
$range_low = ip2long("54.221.0.0");
$range_high = ip2long("54.221.255.255");
$range_low = ip2long("54.250.0.0");
$range_high = ip2long("54.250.255.255");
$range_low = ip2long("175.41.160.0");
$range_high = ip2long("175.41.191.255");
$range_low = ip2long("176.34.8.0");
$range_high = ip2long("176.34.15.255");
$range_low = ip2long("54.255.0.0");
$range_high = ip2long("54.255.255.255");
$range_low = ip2long("54.254.0.0");
$range_high = ip2long("54.254.255.255");
$range_low = ip2long("176.32.80.0");
$range_high = ip2long("176.32.87.255");
$range_low = ip2long("46.137.232.0");
$range_high = ip2long("46.137.239.255");
$range_low = ip2long("54.240.0.0");
$range_high = ip2long("54.255.255.255");
$range_low = ip2long("54.176.0.0");
$range_high = ip2long("54.191.255.255");
$range_low = ip2long("54.196.0.0");
$range_high = ip2long("54.197.255.255");
$range_low = ip2long("54.72.0.0");
$range_high = ip2long("54.95.255.255");
$range_low = ip2long("54.198.0.0");
$range_high = ip2long("54.198.255.255");
$range_low = ip2long("72.21.192.0");
$range_high = ip2long("72.21.223.255");
 
# OVH IP RANGES
 
$range_low = ip2long("188.165.192.0");
$range_high = ip2long("188.165.255.255");
$range_low = ip2long("5.135.5.112");
$range_high = ip2long("5.135.5.127");
$range_low = ip2long("37.59.0.0");
$range_high = ip2long("37.59.63.255");
$range_low = ip2long("178.32.172.96");
$range_high = ip2long("178.32.172.127");
$range_low = ip2long("178.33.169.32");
$range_high = ip2long("178.33.169.47");
 
# RACKSPACE IP RANGES
 
$range_low = ip2long("95.138.176.0");
$range_high = ip2long("95.138.191.255");
 
# JAPAN NETWORK INFORMATION CENTER IP RANGES
 
$range_low = ip2long("133.0.0.0");
$range_high = ip2long("133.255.255.255");
$range_low = ip2long("219.96.0.0");
$range_high = ip2long("219.127.255.255");
$range_low = ip2long("133.11.0.0");
$range_high = ip2long("133.12.255.255");
 
# HOSTING SOLUTIONS UKRAINE IP RANGES
 
$range_low = ip2long("91.213.8.0");
$range_high = ip2long("91.213.8.255");
 
# NEW DREAM NETWORK IP RANGES
 
$range_low = ip2long("64.90.32.0");
$range_high = ip2long("64.90.63.255");
$range_low = ip2long("66.33.192.0");
$range_high = ip2long("66.33.223.255");
$range_low = ip2long("173.236.128.0");
$range_high = ip2long("173.236.255.255");
$range_low = ip2long("205.196.208.0");
$range_high = ip2long("205.196.223.255");
$range_low = ip2long("64.111.96.0");
$range_high = ip2long("64.111.127.255");
$range_low = ip2long("208.97.128.0");
$range_high = ip2long("208.97.191.255");
$range_low = ip2long("208.113.128.0");
$range_high = ip2long("208.113.255.255");
$range_low = ip2long("67.205.0.0");
$range_high = ip2long("67.205.63.255");
$range_low = ip2long("75.119.192.0");
$range_high = ip2long("75.119.223.255");
$range_low = ip2long("69.163.128.0");
$range_high = ip2long("69.163.255.255");
 
# RCS & RDS RESIDENTIAL IP RANGES
 
$range_low = ip2long("5.14.148.0");
$range_high = ip2long("5.14.148.255");
$range_low = ip2long("5.13.164.0");
$range_high = ip2long("5.13.164.255");
 
# TORNET IP RANGES
 
$range_low = ip2long("171.25.193.0");
$range_high = ip2long("171.25.193.255");
 
# ROMTELECOM IP RANGES
 
$range_low = ip2long("109.103.215.0");
$range_high = ip2long("109.103.215.255");
$range_low = ip2long("89.122.0.0");
$range_high = ip2long("89.122.255.255");
 
# NETPILOT ( CLEAN-MX.DE ) IP RANGES
 
$range_low = ip2long("195.214.79.0");
$range_high = ip2long("195.214.79.255");
$range_low = ip2long("195.214.5.0");
$range_high = ip2long("195.214.5.255");
$range_low = ip2long("62.67.240.0");
$range_high = ip2long("62.67.241.255");
$range_low = ip2long("81.171.250.104");
$range_high = ip2long("81.171.250.111");
$range_low = ip2long("89.206.141.13");
$range_high = ip2long("89.206.141.13");
 
# DATAPIPE IP RANGES
 
$range_low = ip2long("65.17.248.0");
$range_high = ip2long("65.17.255.255");
 
# PEER 1 NETWORK IP RANGES
 
$range_low = ip2long("65.39.128.0");
$range_high = ip2long("65.39.255.255");
 
# ANEXIA IP RANGES
 
$range_low = ip2long("37.252.238.0");
$range_high = ip2long("37.252.238.255");
 
# LEXSI IP RANGES
 
$range_low = ip2long("84.14.214.192");
$range_high = ip2long("84.14.214.223");
$range_low = ip2long("92.103.28.224");
$range_high = ip2long("92.103.28.255");
 
# FASTWEB ITALY IP RANGES
 
$range_low = ip2long("2.229.28.0");
$range_high = ip2long("2.229.28.255");
 
# GOOGLE CHROME IP RANGES
 
$range_low = ip2long("66.249.64.0");
$range_high = ip2long("66.249.95.255");
$range_low = ip2long("74.125.0.0");
$range_high = ip2long("74.125.255.255");
$range_low = ip2long("66.102.0.0");
$range_high = ip2long("66.102.15.255");
 
# ADNET TELECOM IP RANGES
 
$range_low = ip2long("31.215.209.0");
$range_high = ip2long("31.215.209.127");
 
# MCAFEE IP RANGES
 
$range_low = ip2long("83.236.159.0");
$range_high = ip2long("83.236.159.7");
$range_low = ip2long("62.189.112.128");
$range_high = ip2long("62.189.112.255");
$range_low = ip2long("194.123.34.184");
$range_high = ip2long("194.123.34.191");
$range_low = ip2long("193.128.126.16");
$range_high = ip2long("193.128.126.23");
$range_low = ip2long("62.189.129.0");
$range_high = ip2long("62.189.129.63");
$range_low = ip2long("194.78.128.132");
$range_high = ip2long("194.78.128.135");
$range_low = ip2long("80.148.18.8");
$range_high = ip2long("80.148.18.15");
$range_low = ip2long("31.161.25.96");
$range_high = ip2long("31.161.25.103");
$range_low = ip2long("31.161.27.96");
$range_high = ip2long("31.161.27.103");
$range_low = ip2long("31.161.90.40");
$range_high = ip2long("31.161.90.47");
$range_low = ip2long("31.149.153.160");
$range_high = ip2long("31.149.153.167");
$range_low = ip2long("12.39.242.112");
$range_high = ip2long("12.39.242.119");
$range_low = ip2long("12.22.195.192");
$range_high = ip2long("12.22.195.199");
$range_low = ip2long("174.90.35.192");
$range_high = ip2long("174.90.35.207");
$range_low = ip2long("208.42.249.0");
$range_high = ip2long("208.42.249.15");
$range_low = ip2long("12.190.240.128");
$range_high = ip2long("12.190.240.255");
$range_low = ip2long("192.187.128.0");
$range_high = ip2long("192.187.128.255");
$range_low = ip2long("216.49.80.0");
$range_high = ip2long("216.49.95.255");
$range_low = ip2long("161.69.0.0");
$range_high = ip2long("161.69.255.255");
$range_low = ip2long("165.193.42.64");
$range_high = ip2long("165.193.42.127");
$range_low = ip2long("216.35.7.96");
$range_high = ip2long("216.35.7.127");
$range_low = ip2long("165.193.42.128");
$range_high = ip2long("165.193.42.191");
$range_low = ip2long("208.69.152.0");
$range_high = ip2long("208.69.159.255");
$range_low = ip2long("205.139.39.0");
$range_high = ip2long("205.139.39.63");
$range_low = ip2long("64.41.151.0");
$range_high = ip2long("64.41.151.255");
$range_low = ip2long("64.41.168.232");
$range_high = ip2long("64.41.168.239");
$range_low = ip2long("12.181.44.192");
$range_high = ip2long("12.181.44.199");
$range_low = ip2long("12.184.29.176");
$range_high = ip2long("12.184.29.191");
$range_low = ip2long("64.41.199.48");
$range_high = ip2long("64.41.199.55");
$range_low = ip2long("8.21.160.0");
$range_high = ip2long("8.21.163.255");
$range_low = ip2long("8.18.24.0");
$range_high = ip2long("8.18.27.255");
 
# HOSTWAY ROMANIA IP RANGES
 
$range_low = ip2long("193.223.101.0");
$range_high = ip2long("193.223.101.255");
$range_low = ip2long("89.33.207.0");
$range_high = ip2long("89.33.207.255");
$range_low = ip2long("91.209.102.0");
$range_high = ip2long("91.209.102.255");
$range_low = ip2long("83.246.0.0");
$range_high = ip2long("83.246.15.255");
$range_low = ip2long("188.215.38.0");
$range_high = ip2long("188.215.38.255");
$range_low = ip2long("46.102.248.0");
$range_high = ip2long("46.102.248.255");
$range_low = ip2long("193.226.167.120");
$range_high = ip2long("193.226.167.123");
$range_low = ip2long("89.41.60.0");
$range_high = ip2long("89.41.61.255");
$range_low = ip2long("176.223.192.0");
$range_high = ip2long("176.223.255.255");
 
# NOISEBRIDGE IP RANGES
 
$range_low = ip2long("173.254.216.64");
$range_high = ip2long("173.254.216.95");
 
# QUBE MANAGED SERVICES IP RANGES
 
$range_low = ip2long("81.91.253.0");
$range_high = ip2long("81.91.253.255");
 
# FORMLESS NETWORKING IP RANGES
 
$range_low = ip2long("199.48.147.32");
$range_high = ip2long("199.48.147.47");
 
# CHAOS COMPUTER CLUB IP RANGES
 
$range_low = ip2long("31.172.30.0");
$range_high = ip2long("31.172.30.7");
$range_low = ip2long("217.115.10.128");
$range_high = ip2long("217.115.10.143");
$range_low = ip2long("77.244.254.224");
$range_high = ip2long("77.244.254.231");
 
# MICROSOFT SINGAPORE IP RANGES
 
$range_low = ip2long("111.221.16.0");
$range_high = ip2long("111.221.31.255");
 
# ALIENVAULT IP RANGES
 
$range_low = ip2long("70.38.42.24");
$range_high = ip2long("70.38.42.31");
$range_low = ip2long("174.142.24.120");
$range_high = ip2long("174.142.24.127");
$range_low = ip2long("174.142.215.160");
$range_high = ip2long("174.142.215.167");
$range_low = ip2long("184.107.46.208");
$range_high = ip2long("184.107.46.215");
$range_low = ip2long("184.107.139.168");
$range_high = ip2long("184.107.139.175");
$range_low = ip2long("184.107.145.160");
$range_high = ip2long("184.107.145.167");
$range_low = ip2long("198.50.107.80");
$range_high = ip2long("198.50.107.87");
 
# AVIRA IP RANGES
 
$range_low = ip2long("81.12.221.96");
$range_high = ip2long("81.12.221.127");
$range_low = ip2long("62.146.66.176");
$range_high = ip2long("62.146.66.191");
$range_low = ip2long("195.243.52.96");
$range_high = ip2long("195.243.52.103");
$range_low = ip2long("62.157.152.32");
$range_high = ip2long("62.157.152.63");
$range_low = ip2long("62.146.87.168");
$range_high = ip2long("62.146.87.175");
$range_low = ip2long("62.146.210.0");
$range_high = ip2long("62.146.210.255");
$range_low = ip2long("62.146.40.24");
$range_high = ip2long("62.146.40.31");
$range_low = ip2long("80.190.143.224");
$range_high = ip2long("80.190.143.255");
$range_low = ip2long("62.146.211.0");
$range_high = ip2long("62.146.211.255");
$range_low = ip2long("80.190.155.0");
$range_high = ip2long("80.190.155.255");
$range_low = ip2long("80.190.154.0");
$range_high = ip2long("80.190.154.255");
$range_low = ip2long("80.190.129.16");
$range_high = ip2long("80.190.129.23");
$range_low = ip2long("80.190.133.160");
$range_high = ip2long("80.190.133.175");
$range_low = ip2long("212.211.136.112");
$range_high = ip2long("212.211.136.119");
$range_low = ip2long("62.146.64.144");
$range_high = ip2long("62.146.64.159");
$range_low = ip2long("80.190.130.224");
$range_high = ip2long("80.190.130.255");
$range_low = ip2long("80.190.130.192");
$range_high = ip2long("80.190.130.223");
$range_low = ip2long("212.62.197.128");
$range_high = ip2long("212.62.197.191");
$range_low = ip2long("89.105.212.0");
$range_high = ip2long("89.105.212.127");
$range_low = ip2long("212.79.247.128");
$range_high = ip2long("212.79.247.255");
$range_low = ip2long("89.105.213.128");
$range_high = ip2long("89.105.213.255");
$range_low = ip2long("89.105.212.168");
$range_high = ip2long("89.105.212.175");
$range_low = ip2long("89.105.214.32");
$range_high = ip2long("89.105.214.63");
$range_low = ip2long("62.146.28.120");
$range_high = ip2long("62.146.28.127");
$range_low = ip2long("89.105.213.64");
$range_high = ip2long("89.105.213.127");
$range_low = ip2long("89.105.216.0");
$range_high = ip2long("89.105.217.255");
$range_low = ip2long("80.190.148.96");
$range_high = ip2long("80.190.148.127");
$range_low = ip2long("80.190.148.64");
$range_high = ip2long("80.190.148.95");
$range_low = ip2long("89.105.206.240");
$range_high = ip2long("89.105.206.247");
$range_low = ip2long("212.114.195.64");
$range_high = ip2long("212.114.195.71");
$range_low = ip2long("5.153.4.224");
$range_high = ip2long("5.153.4.231");
$range_low = ip2long("89.105.200.96");
$range_high = ip2long("89.105.200.111");
 
# COMODO GROUP IP RANGES
 
$range_low = ip2long("67.23.50.0");
$range_high = ip2long("67.23.51.255");
$range_low = ip2long("199.66.200.0");
$range_high = ip2long("199.66.207.255");
$range_low = ip2long("97.107.175.140");
$range_high = ip2long("97.107.175.143");
$range_low = ip2long("70.36.29.32");
$range_high = ip2long("70.36.29.35");
$range_low = ip2long("70.36.29.24");
$range_high = ip2long("70.36.29.27");
$range_low = ip2long("82.109.38.200");
$range_high = ip2long("82.109.38.207");
$range_low = ip2long("82.110.55.12");
$range_high = ip2long("82.110.55.15");
$range_low = ip2long("85.91.228.128");
$range_high = ip2long("85.91.228.191");
$range_low = ip2long("91.199.212.0");
$range_high = ip2long("91.199.212.255");
$range_low = ip2long("91.209.196.0");
$range_high = ip2long("91.209.196.255");
$range_low = ip2long("91.212.12.0");
$range_high = ip2long("91.212.12.255");
$range_low = ip2long("82.113.138.16");
$range_high = ip2long("82.113.138.23");
$range_low = ip2long("88.39.235.56");
$range_high = ip2long("88.39.235.63");
$range_low = ip2long("193.104.21.0");
$range_high = ip2long("193.104.21.255");
$range_low = ip2long("178.255.82.0");
$range_high = ip2long("178.255.82.127");
$range_low = ip2long("178.255.83.0");
$range_high = ip2long("178.255.83.63");
$range_low = ip2long("199.66.200.0 ");
$range_high = ip2long(" 199.66.207.255");
 
# AVG TECHNOLOGIES IP RANGES
 
$range_low = ip2long("212.96.161.224");
$range_high = ip2long("212.96.161.255");
$range_low = ip2long("212.96.183.0");
$range_high = ip2long("212.96.183.31");
$range_low = ip2long("213.7.204.176");
$range_high = ip2long("213.7.204.191");
$range_low = ip2long("82.142.105.96");
$range_high = ip2long("82.142.105.111");
$range_low = ip2long("213.106.147.112");
$range_high = ip2long("213.106.147.127");
$range_low = ip2long("212.4.138.48");
$range_high = ip2long("212.4.138.63");
$range_low = ip2long("212.4.138.128");
$range_high = ip2long("212.4.138.191");
$range_low = ip2long("212.4.138.224");
$range_high = ip2long("212.4.138.255");
$range_low = ip2long("89.233.128.96");
$range_high = ip2long("89.233.128.111");
$range_low = ip2long("193.85.33.208");
$range_high = ip2long("193.85.33.223");
$range_low = ip2long("212.4.152.224");
$range_high = ip2long("212.4.152.255");
$range_low = ip2long("212.96.161.96");
$range_high = ip2long("212.96.161.127");
$range_low = ip2long("195.5.219.216");
$range_high = ip2long("195.5.219.223");
$range_low = ip2long("212.67.80.0");
$range_high = ip2long("212.67.80.63");
$range_low = ip2long("212.67.69.232");
$range_high = ip2long("212.67.69.239");
$range_low = ip2long("93.184.217.0");
$range_high = ip2long("93.184.217.31");
$range_low = ip2long("93.184.217.32");
$range_high = ip2long("93.184.217.47");
$range_low = ip2long("93.184.217.64");
$range_high = ip2long("93.184.217.127");
$range_low = ip2long("93.184.211.64");
$range_high = ip2long("93.184.211.127");
$range_low = ip2long("93.184.211.0");
$range_high = ip2long("93.184.211.31");
$range_low = ip2long("212.4.153.64");
$range_high = ip2long("212.4.153.79");
$range_low = ip2long("72.3.156.160");
$range_high = ip2long("72.3.156.175");
 
# ESET IP RANGES
 
$range_low = ip2long("213.215.116.224");
$range_high = ip2long("213.215.116.239");
$range_low = ip2long("212.47.6.196");
$range_high = ip2long("212.47.6.199");
$range_low = ip2long("195.46.70.40");
$range_high = ip2long("195.46.70.47");
$range_low = ip2long("88.208.109.228");
$range_high = ip2long("88.208.109.231");
$range_low = ip2long("195.168.53.48");
$range_high = ip2long("195.168.53.63");
$range_low = ip2long("217.75.75.88");
$range_high = ip2long("217.75.75.95");
$range_low = ip2long("217.75.75.96");
$range_high = ip2long("217.75.75.127");
$range_low = ip2long("77.78.101.144");
$range_high = ip2long("77.78.101.159");
$range_low = ip2long("88.208.88.0");
$range_high = ip2long("88.208.88.127");
$range_low = ip2long("77.78.102.0");
$range_high = ip2long("77.78.102.255");
$range_low = ip2long("193.85.203.144");
$range_high = ip2long("193.85.203.159");
$range_low = ip2long("62.67.186.0");
$range_high = ip2long("62.67.186.255");
$range_low = ip2long("94.112.253.168");
$range_high = ip2long("94.112.253.175");
 
# DOCTOR WEB IP RANGES
 
$range_low = ip2long("195.88.252.0");
$range_high = ip2long("195.88.253.255");
$range_low = ip2long("194.85.20.0");
$range_high = ip2long("194.85.20.255");
 
# PANDA SECURITY IP RANGES
 
$range_low = ip2long("195.235.47.0");
$range_high = ip2long("195.235.47.255");
$range_low = ip2long("195.235.200.0");
$range_high = ip2long("195.235.200.255");
$range_low = ip2long("193.104.218.0");
$range_high = ip2long("193.104.218.255");
$range_low = ip2long("62.7.85.16");
$range_high = ip2long("62.7.85.31");
$range_low = ip2long("91.216.218.0");
$range_high = ip2long("91.216.218.255");
$range_low = ip2long("62.97.120.240");
$range_high = ip2long("62.97.120.247");
$range_low = ip2long("195.76.4.168");
$range_high = ip2long("195.76.4.175");
$range_low = ip2long("195.76.195.160");
$range_high = ip2long("195.76.195.167");
$range_low = ip2long("62.99.71.113");
$range_high = ip2long("62.99.71.113");
$range_low = ip2long("62.99.76.3");
$range_high = ip2long("62.99.76.3");
$range_low = ip2long("62.99.77.165");
$range_high = ip2long("62.99.77.165");
$range_low = ip2long("62.99.77.184");
$range_high = ip2long("62.99.77.184");
$range_low = ip2long("62.99.78.125");
$range_high = ip2long("62.99.78.125");
$range_low = ip2long("62.99.80.195");
$range_high = ip2long("62.99.80.195");
$range_low = ip2long("212.8.79.64");
$range_high = ip2long("212.8.79.127");
$range_low = ip2long("212.142.140.122");
$range_high = ip2long("212.142.140.127");
$range_low = ip2long("212.142.148.66");
$range_high = ip2long("212.142.148.66");
$range_low = ip2long("212.142.175.22");
$range_high = ip2long("212.142.175.22");
 
# SYMANTEC IP RANGES
 
$range_low = ip2long("213.156.160.0");
$range_high = ip2long("213.156.191.255");
$range_low = ip2long("195.212.45.32");
$range_high = ip2long("195.212.45.63");
$range_low = ip2long("62.190.166.192");
$range_high = ip2long("62.190.166.255");
$range_low = ip2long("62.99.191.24");
$range_high = ip2long("62.99.191.31");
$range_low = ip2long("195.75.106.64");
$range_high = ip2long("195.75.106.95");
$range_low = ip2long("212.226.130.152");
$range_high = ip2long("212.226.130.159");
$range_low = ip2long("80.227.131.216");
$range_high = ip2long("80.227.131.223");
$range_low = ip2long("213.88.133.112");
$range_high = ip2long("213.88.133.119");
$range_low = ip2long("213.156.161.0");
$range_high = ip2long("213.156.161.31");
$range_low = ip2long("213.156.162.64");
$range_high = ip2long("213.156.162.79");
$range_low = ip2long("213.156.162.112");
$range_high = ip2long("213.156.162.127");
$range_low = ip2long("213.156.163.0");
$range_high = ip2long("213.156.163.255");
$range_low = ip2long("213.156.170.0");
$range_high = ip2long("213.156.170.255");
$range_low = ip2long("83.64.142.128");
$range_high = ip2long("83.64.142.135");
$range_low = ip2long("213.139.240.184");
$range_high = ip2long("213.139.240.191");
$range_low = ip2long("62.237.120.128");
$range_high = ip2long("62.237.120.135");
$range_low = ip2long("213.71.162.0");
$range_high = ip2long("213.71.162.15");
$range_low = ip2long("217.33.67.16");
$range_high = ip2long("217.33.67.31");
$range_low = ip2long("217.89.94.24");
$range_high = ip2long("217.89.94.31");
$range_low = ip2long("213.47.214.40");
$range_high = ip2long("213.47.214.47");
$range_low = ip2long("192.92.94.0");
$range_high = ip2long("192.92.94.255");
$range_low = ip2long("213.156.160.0");
$range_high = ip2long("213.156.160.255");
$range_low = ip2long("194.100.208.224");
$range_high = ip2long("194.100.208.239");
$range_low = ip2long("194.16.221.144");
$range_high = ip2long("194.16.221.159");
$range_low = ip2long("195.198.213.160");
$range_high = ip2long("195.198.213.163");
$range_low = ip2long("78.136.60.0");
$range_high = ip2long("78.136.60.7");
$range_low = ip2long("62.17.134.112");
$range_high = ip2long("62.17.134.119");
$range_low = ip2long("194.78.121.16");
$range_high = ip2long("194.78.121.23");
$range_low = ip2long("31.222.134.12");
$range_high = ip2long("31.222.134.15");
$range_low = ip2long("62.17.145.232");
$range_high = ip2long("62.17.145.239");
$range_low = ip2long("217.33.59.160");
$range_high = ip2long("217.33.59.175");
$range_low = ip2long("199.43.185.0");
$range_high = ip2long("199.43.194.255");
$range_low = ip2long("199.85.125.0");
$range_high = ip2long("199.85.127.255");
$range_low = ip2long("198.6.32.0");
$range_high = ip2long("198.6.63.255");
$range_low = ip2long("204.178.110.224");
$range_high = ip2long("204.178.110.255");
$range_low = ip2long("216.10.192.0");
$range_high = ip2long("216.10.207.255");
$range_low = ip2long("155.64.0.0");
$range_high = ip2long("155.64.255.255");
$range_low = ip2long("206.204.10.192");
$range_high = ip2long("206.204.10.223");
$range_low = ip2long("216.250.16.0");
$range_high = ip2long("216.250.31.255");
$range_low = ip2long("208.185.197.0");
$range_high = ip2long("208.185.197.255");
$range_low = ip2long("216.35.137.160");
$range_high = ip2long("216.35.137.191");
$range_low = ip2long("216.35.137.128");
$range_high = ip2long("216.35.137.143");
$range_low = ip2long("216.35.137.192");
$range_high = ip2long("216.35.137.255");
$range_low = ip2long("198.187.197.0");
$range_high = ip2long("198.187.198.255");
$range_low = ip2long("198.153.190.0");
$range_high = ip2long("198.153.196.255");
$range_low = ip2long("166.98.0.0");
$range_high = ip2long("166.98.255.255");
$range_low = ip2long("192.251.86.0");
$range_high = ip2long("192.251.86.255");
$range_low = ip2long("143.127.0.0");
$range_high = ip2long("143.127.255.255");
$range_low = ip2long("64.171.125.128");
$range_high = ip2long("64.171.125.135");
$range_low = ip2long("208.194.116.0");
$range_high = ip2long("208.194.116.255");
$range_low = ip2long("208.194.152.0");
$range_high = ip2long("208.194.152.255");
$range_low = ip2long("208.213.242.0");
$range_high = ip2long("208.213.242.255");
$range_low = ip2long("208.185.207.0");
$range_high = ip2long("208.185.207.255");
$range_low = ip2long("63.110.89.208");
$range_high = ip2long("63.110.89.223");
$range_low = ip2long("209.249.184.0");
$range_high = ip2long("209.249.184.255");
$range_low = ip2long("209.249.114.0");
$range_high = ip2long("209.249.114.255");
$range_low = ip2long("65.214.150.48");
$range_high = ip2long("65.214.150.55");
$range_low = ip2long("63.110.247.0");
$range_high = ip2long("63.110.247.31");
$range_low = ip2long("66.45.123.16");
$range_high = ip2long("66.45.123.31");
$range_low = ip2long("72.32.137.226");
$range_high = ip2long("72.32.137.227");
 
# INETU INC IP RANGES
 
$range_low = ip2long("94.103.24.0");
$range_high = ip2long("94.103.24.127");
$range_low = ip2long("94.103.31.0");
$range_high = ip2long("94.103.31.255");
$range_low = ip2long("94.103.24.128");
$range_high = ip2long("94.103.24.255");
$range_low = ip2long("159.255.220.128");
$range_high = ip2long("159.255.220.223");
$range_low = ip2long("209.235.192.0");
$range_high = ip2long("209.235.255.255");
$range_low = ip2long("74.85.128.0");
$range_high = ip2long("74.85.143.255");
 
# ABOVENET COMM. IP RANGES
 
$range_low = ip2long("64.124.0.0");
$range_high = ip2long("64.125.255.255");
$range_low = ip2long("209.66.64.0");
$range_high = ip2long("209.66.127.255");
 
# LEVEL 3 COMM. IP RANGES
 
$range_low = ip2long("208.48.224.0");
$range_high = ip2long("208.50.127.255");
 
# INTERNAP IP RANGES
 
$range_low = ip2long("74.217.0.0");
$range_high = ip2long("74.217.255.255");
 
# INTERNET IDENTITY IP RANGES
 
$range_low = ip2long("66.150.14.160");
$range_high = ip2long("66.150.14.191");
$range_low = ip2long("63.251.10.176");
$range_high = ip2long("63.251.10.191");
$range_low = ip2long("63.251.6.112");
$range_high = ip2long("63.251.6.127");
$range_low = ip2long("66.150.9.128");
$range_high = ip2long("66.150.9.191");
$range_low = ip2long("69.25.31.160");
$range_high = ip2long("69.25.31.191");
$range_low = ip2long("69.25.48.0");
$range_high = ip2long("69.25.62.255"); 
$range_low = ip2long("66.151.97.64");
$range_high = ip2long("66.151.97.127");
 
# RELIANCE INFOCOM INDIA IP RANGES
 
$range_low = ip2long("220.225.69.0");
$range_high = ip2long("220.225.72.255");
 
# MICROSOFT IP RANGES 

$range_low = ip2long("208.80.192.0");
$range_high = ip2long("208.80.207.255");
$range_low = ip2long("13.93.128.0");
$range_high = ip2long("13.93.255.255");
$range_low = ip2long("40.78.0.0");
$range_high = ip2long("40.78.127.255");
$range_low = ip2long("51.143.0.0");
$range_high = ip2long("51.143.127.255");
$range_low = ip2long("52.191.128.0");
$range_high = ip2long("52.191.191.255");
$range_low = ip2long("52.183.74.0");
$range_high = ip2long("52.183.127.255");
$range_low = ip2long("157.55.160.0");
$range_high = ip2long("157.55.175.255");
$range_low = ip2long("40.113.192.0");
$range_high = ip2long("40.113.255.255");
$range_low = ip2long("65.52.0.0");
$range_high = ip2long("65.55.255.255");
$range_low = ip2long("52.183.48.0");
$range_high = ip2long("52.183.71.255"); 
 
# G-DATA SOFTWARE IP RANGES
 
$range_low = ip2long("195.205.70.0");
$range_high = ip2long("195.205.70.255");
$range_low = ip2long("212.23.128.176");
$range_high = ip2long("212.23.128.179");
$range_low = ip2long("212.23.140.96");
$range_high = ip2long("212.23.140.127");
$range_low = ip2long("212.23.136.48");
$range_high = ip2long("212.23.136.63");
 
# SOPHOS IP RANGES
 
$range_low = ip2long("194.203.134.128");
$range_high = ip2long("194.203.134.255");
$range_low = ip2long("213.86.172.128");
$range_high = ip2long("213.86.172.159");
$range_low = ip2long("212.161.106.240");
$range_high = ip2long("212.161.106.247");
$range_low = ip2long("85.35.56.80");
$range_high = ip2long("85.35.56.87");
$range_low = ip2long("88.44.165.208");
$range_high = ip2long("88.44.165.223");
$range_low = ip2long("81.93.18.144");
$range_high = ip2long("81.93.18.151");
$range_low = ip2long("213.139.142.80");
$range_high = ip2long("213.139.142.95");
$range_low = ip2long("81.223.13.240");
$range_high = ip2long("81.223.13.255");
$range_low = ip2long("85.126.49.88");
$range_high = ip2long("85.126.49.95");
$range_low = ip2long("85.222.200.248");
$range_high = ip2long("85.222.200.255");
$range_low = ip2long("193.189.184.158");
$range_high = ip2long("193.189.184.158");
$range_low = ip2long("145.253.124.128");
$range_high = ip2long("145.253.124.159");
$range_low = ip2long("195.171.192.0");
$range_high = ip2long("195.171.192.127");
$range_low = ip2long("195.171.192.128");
$range_high = ip2long("195.171.192.255");
$range_low = ip2long("212.243.136.40");
$range_high = ip2long("212.243.136.47");
$range_low = ip2long("178.15.194.112");
$range_high = ip2long("178.15.194.127");
$range_low = ip2long("195.65.248.136");
$range_high = ip2long("195.65.248.143");
 
# DATATRAN SYSTEMS IP RANGES
 
$range_low = ip2long("204.12.235.0");
$range_high = ip2long("204.12.235.31");
$range_low = ip2long("216.22.45.128");
$range_high = ip2long("216.22.45.159");
$range_low = ip2long("204.12.237.8");
$range_high = ip2long("204.12.237.15");
$range_low = ip2long("204.12.194.0");
$range_high = ip2long("204.12.194.31");
$range_low = ip2long("204.12.244.32");
$range_high = ip2long("204.12.244.47");
$range_low = ip2long("204.12.224.32");
$range_high = ip2long("204.12.224.63");
$range_low = ip2long("204.12.248.96");
$range_high = ip2long("204.12.248.127");
$range_low = ip2long("204.12.248.224");
$range_high = ip2long("204.12.248.255");
$range_low = ip2long("204.12.202.32");
$range_high = ip2long("204.12.202.63");
$range_low = ip2long("204.12.248.128");
$range_high = ip2long("204.12.248.159");
$range_low = ip2long("204.12.192.192");
$range_high = ip2long("204.12.192.223");
 
# NETSUMO IP RANGES
 
$range_low = ip2long("37.130.227.128");
$range_high = ip2long("37.130.227.135");
 
# THE NEW YORK INTERNET COMPANY IP RANGES
 
$range_low = ip2long("204.248.157.0");
$range_high = ip2long("204.248.157.255");
$range_low = ip2long("207.12.88.0");
$range_high = ip2long("207.12.95.255");
$range_low = ip2long("63.165.240.0");
$range_high = ip2long("63.165.255.255");
$range_low = ip2long("64.90.160.0");
$range_high = ip2long("64.90.191.255");
$range_low = ip2long("66.111.0.0");
$range_high = ip2long("66.111.15.255");
$range_low = ip2long("204.97.244.0");
$range_high = ip2long("204.97.244.255");
$range_low = ip2long("67.221.176.0");
$range_high = ip2long("67.221.191.255");
$range_low = ip2long("64.147.96.0");
$range_high = ip2long("64.147.127.255");
$range_low = ip2long("173.228.128.0");
$range_high = ip2long("173.228.159.255");
$range_low = ip2long("96.47.64.0");
$range_high = ip2long("96.47.79.255");
$range_low = ip2long("199.83.60.0");
$range_high = ip2long("199.83.63.255");
$range_low = ip2long("162.208.116.0");
$range_high = ip2long("162.208.119.255");
 
# TECHCREA SOLUTIONS IP RANGES
 
$range_low = ip2long("91.229.20.0");
$range_high = ip2long("91.229.20.255");
$range_low = ip2long("91.236.239.0");
$range_high = ip2long("91.236.239.255");
$range_low = ip2long("91.236.254.0");
$range_high = ip2long("91.236.255.255");
$range_low = ip2long("185.13.36.0");
$range_high = ip2long("185.13.37.255");
$range_low = ip2long("185.13.38.0");
$range_high = ip2long("185.13.39.255");
 
# SOLUTIONPRO INC. IP RANGES
 
$range_low = ip2long("204.228.192.0");
$range_high = ip2long("204.228.255.255");
$range_low = ip2long("198.60.192.0");
$range_high = ip2long("198.60.255.255");
$range_low = ip2long("206.207.64.0");
$range_high = ip2long("206.207.127.255");
$range_low = ip2long("204.229.96.0");
$range_high = ip2long("204.229.127.255");
$range_low = ip2long("199.104.0.0");
$range_high = ip2long("199.104.63.255");
$range_low = ip2long("206.206.0.0");
$range_high = ip2long("206.206.63.255");
$range_low = ip2long("204.229.0.0");
$range_high = ip2long("204.229.31.255");
$range_low = ip2long("204.134.200.0");
$range_high = ip2long("204.134.215.255");
$range_low = ip2long("204.134.222.0");
$range_high = ip2long("204.134.223.255");
$range_low = ip2long("204.134.232.0");
$range_high = ip2long("204.134.239.255");
 
# MOSCOW LOCAL TELEPHONE NETWORK IP RANGES
 
$range_low = ip2long("94.29.0.0");
$range_high = ip2long("94.29.63.255");
 
# MAXIS BROADBAND MALAYSIA IP RANGES
 
$range_low = ip2long("113.210.35.0");
$range_high = ip2long("113.210.39.255");
 
# 2COM CO IP RANGES
 
$range_low = ip2long("188.244.35.0");
$range_high = ip2long("188.244.35.255");
 
# POWERTECH INFO SYSTEMS IP RANGES
 
$range_low = ip2long("195.159.140.0");
$range_high = ip2long("195.159.140.255");
 
# LINODE IP RANGES
 
$range_low = ip2long("173.255.192.0");
$range_high = ip2long("173.255.255.255");
$range_low = ip2long("198.58.96.0");
$range_high = ip2long("198.58.127.255");
$range_low = ip2long("96.126.96.0");
$range_high = ip2long("96.126.127.255");
$range_low = ip2long("66.228.32.0");
$range_high = ip2long("66.228.63.255");
$range_low = ip2long("192.155.80.0");
$range_high = ip2long("192.155.95.255");
$range_low = ip2long("72.14.176.0");
$range_high = ip2long("72.14.191.255");
$range_low = ip2long("97.107.128.0");
$range_high = ip2long("97.107.143.255");
$range_low = ip2long("74.207.224.0");
$range_high = ip2long("74.207.255.255");
$range_low = ip2long("173.230.128.0");
$range_high = ip2long("173.230.159.255");
$range_low = ip2long("198.74.48.0");
$range_high = ip2long("198.74.63.255");
$range_low = ip2long("192.81.128.0");
$range_high = ip2long("192.81.135.255");
$range_low = ip2long("50.116.0.0");
$range_high = ip2long("50.116.63.255");
$range_low = ip2long("66.175.208.0");
$range_high = ip2long("66.175.223.255");
$range_low = ip2long("162.216.16.0");
$range_high = ip2long("162.216.19.255");
 
# ARUBA S.P.A. IP RANGES
 
$range_low = ip2long("62.149.224.0");
$range_high = ip2long("62.149.255.255");
 
# MASSACHUSETTS INSTITUTE OF TECHNOLOGY IP RANGES
 
$range_low = ip2long("128.30.0.0");
$range_high = ip2long("128.30.255.255");
$range_low = ip2long("128.31.0.0");
$range_high = ip2long("128.31.255.255");
$range_low = ip2long("192.233.95.0");
$range_high = ip2long("192.233.95.255");
$range_low = ip2long("18.0.0.0");
$range_high = ip2long("18.255.255.255");
$range_low = ip2long("128.52.0.0");
$range_high = ip2long("128.52.255.255");
$range_low = ip2long("4.21.160.8");
$range_high = ip2long("4.21.160.15");
$range_low = ip2long("192.12.11.0");
$range_high = ip2long("192.12.11.255");
$range_low = ip2long("192.54.222.0");
$range_high = ip2long("192.54.222.255");
 
# INTEGRA TELECOM IP RANGES
 
$range_low = ip2long("64.122.0.0");
$range_high = ip2long("64.122.255.255");
$range_low = ip2long("70.98.0.0");
$range_high = ip2long("70.98.255.255");
 
# ZWIEBELFREUNDE ( TOR EXIT NODES ) IP RANGES
 
$range_low = ip2long("77.247.181.160");
$range_high = ip2long("77.247.181.175");
$range_low = ip2long("109.163.233.192");
$range_high = ip2long("109.163.233.207");
$range_low = ip2long("192.36.27.0");
$range_high = ip2long("192.36.27.255");
$range_low = ip2long("192.36.31.0");
$range_high = ip2long("192.36.31.255");
$range_low = ip2long("192.36.41.0");
$range_high = ip2long("192.36.41.255");
$range_low = ip2long("192.36.61.0");
$range_high = ip2long("192.36.61.255");
 
# AT&T IP RANGES
 
$range_low = ip2long("99.107.207.0");
$range_high = ip2long("99.107.207.255");
 
# MALCOVERY SECURITY IP RANGES
 
$range_low = ip2long("166.78.235.176");
$range_high = ip2long("166.78.235.183");
$range_low = ip2long("166.78.235.60");
$range_high = ip2long("166.78.235.63");
 
# TIME WARNER CABLE IP RANGES
 
$range_low = ip2long("67.78.0.0");
$range_high = ip2long("67.79.255.255");
 
# OPAL TELECOM DSL IP RANGES
 
$range_low = ip2long("92.24.0.0");
$range_high = ip2long("92.25.255.255");
$range_low = ip2long("78.151.0.0");
$range_high = ip2long("78.151.255.255");
$range_low = ip2long("78.146.0.0");
$range_high = ip2long("78.146.255.255");
 
# BEZEQINT BROADBAND IP RANGES
 
$range_low = ip2long("109.64.0.0");
$range_high = ip2long("109.64.255.255");
$range_low = ip2long("84.110.238.0");
$range_high = ip2long("84.110.242.255");
 
# UNSPAM TECHNOLOGIES IP RANGES
 
$range_low = ip2long("66.114.197.224");
$range_high = ip2long("66.114.197.255");
$range_low = ip2long("209.124.55.32");
$range_high = ip2long("209.124.55.63");
 
# HURRICANE ELECTRIC IP RANGES
 
$range_low = ip2long("64.62.128.0");
$range_high = ip2long("64.62.255.255");
 
# TELUS COMMUNICATIONS IP RANGES
 
$range_low = ip2long("207.102.137.0");
$range_high = ip2long("207.102.138.255");
 
# NEOSTRADA ADSL IP RANGES
 
$range_low = ip2long("79.185.218.0");
$range_high = ip2long("79.185.219.255");
 
# MAROCTELECOM IP RANGES
 
$range_low = ip2long("41.140.46.0");
$range_high = ip2long("41.140.47.255");
 
# HOSTDIME IP RANGES
 
$range_low = ip2long("64.37.48.0");
$range_high = ip2long("64.37.63.255");
$range_low = ip2long("199.168.184.0");
$range_high = ip2long("199.168.191.255");
$range_low = ip2long("66.195.16.0");
$range_high = ip2long("66.195.17.255");
$range_low = ip2long("66.195.18.0");
$range_high = ip2long("66.195.19.255");
$range_low = ip2long("66.195.124.0");
$range_high = ip2long("66.195.125.255");
$range_low = ip2long("66.195.126.0");
$range_high = ip2long("66.195.127.255");
$range_low = ip2long("66.195.240.0");
$range_high = ip2long("66.195.243.255");
$range_low = ip2long("72.29.64.0");
$range_high = ip2long("72.29.95.255");
$range_low = ip2long("67.23.224.0");
$range_high = ip2long("67.23.255.255");
$range_low = ip2long("66.7.192.0");
$range_high = ip2long("66.7.223.255");
$range_low = ip2long("184.171.240.0");
$range_high = ip2long("184.171.255.255");
$range_low = ip2long("8.33.160.0");
$range_high = ip2long("8.33.167.255");
$range_low = ip2long("8.33.168.0");
$range_high = ip2long("8.33.175.255");
$range_low = ip2long("8.19.188.0");
$range_high = ip2long("8.19.191.255");
$range_low = ip2long("198.136.48.0");
$range_high = ip2long("198.136.63.255");
$range_low = ip2long("198.49.64.0");
$range_high = ip2long("198.49.79.255");
 
# HETZNER ONLINE IP RANGES
 
$range_low = ip2long("80.150.215.0");
$range_high = ip2long("80.150.215.255");
$range_low = ip2long("213.239.210.0");
$range_high = ip2long("213.239.211.255");
$range_low = ip2long("213.133.96.0");
$range_high = ip2long("213.133.127.255");
$range_low = ip2long("62.128.13.200");
$range_high = ip2long("62.128.13.203");
$range_low = ip2long("213.239.192.0");
$range_high = ip2long("213.239.255.255");
$range_low = ip2long("85.10.192.0");
$range_high = ip2long("85.10.255.255");
$range_low = ip2long("193.47.99.0");
$range_high = ip2long("193.47.99.255");
$range_low = ip2long("85.10.208.0");
$range_high = ip2long("85.10.215.255");
$range_low = ip2long("88.198.0.0");
$range_high = ip2long("88.198.255.255");
$range_low = ip2long("213.239.192.0");
$range_high = ip2long("213.239.199.255");
$range_low = ip2long("213.239.200.0");
$range_high = ip2long("213.239.201.255");
$range_low = ip2long("213.239.204.0");
$range_high = ip2long("213.239.207.255");
$range_low = ip2long("85.10.249.240");
$range_high = ip2long("85.10.249.255");
$range_low = ip2long("213.133.112.36");
$range_high = ip2long("213.133.112.39");
$range_low = ip2long("213.239.246.192");
$range_high = ip2long("213.239.246.255");
$range_low = ip2long("88.198.16.0");
$range_high = ip2long("88.198.31.255");
$range_low = ip2long("88.198.32.0");
$range_high = ip2long("88.198.63.255");
$range_low = ip2long("213.239.242.248");
$range_high = ip2long("213.239.242.251");
$range_low = ip2long("213.239.242.244");
$range_high = ip2long("213.239.242.247");
$range_low = ip2long("213.239.242.236");
$range_high = ip2long("213.239.242.239");
$range_low = ip2long("88.198.243.224");
$range_high = ip2long("88.198.243.239");
$range_low = ip2long("78.46.0.0");
$range_high = ip2long("78.47.255.255");
$range_low = ip2long("213.239.229.0");
$range_high = ip2long("213.239.229.255");
$range_low = ip2long("213.239.240.0");
$range_high = ip2long("213.239.240.255");
$range_low = ip2long("213.239.252.0");
$range_high = ip2long("213.239.252.255");
$range_low = ip2long("213.239.242.200");
$range_high = ip2long("213.239.242.203");
$range_low = ip2long("78.47.200.192");
$range_high = ip2long("78.47.200.255");
$range_low = ip2long("213.239.239.188");
$range_high = ip2long("213.239.239.191");
$range_low = ip2long("213.133.122.224");
$range_high = ip2long("213.133.122.239");
$range_low = ip2long("88.198.254.200");
$range_high = ip2long("88.198.254.207");
$range_low = ip2long("213.239.242.220");
$range_high = ip2long("213.239.242.223");
$range_low = ip2long("213.239.239.124");
$range_high = ip2long("213.239.239.127");
$range_low = ip2long("213.239.247.200");
$range_high = ip2long("213.239.247.203");
$range_low = ip2long("213.239.239.16");
$range_high = ip2long("213.239.239.19");
$range_low = ip2long("213.239.239.112");
$range_high = ip2long("213.239.239.115");
$range_low = ip2long("213.239.238.0");
$range_high = ip2long("213.239.238.255");
$range_low = ip2long("213.239.239.128");
$range_high = ip2long("213.239.239.131");
$range_low = ip2long("213.239.239.168");
$range_high = ip2long("213.239.239.171");
$range_low = ip2long("213.239.239.172");
$range_high = ip2long("213.239.239.175");
$range_low = ip2long("213.239.239.44");
$range_high = ip2long("213.239.239.47");
$range_low = ip2long("213.239.242.208");
$range_high = ip2long("213.239.242.211");
$range_low = ip2long("213.239.247.208");
$range_high = ip2long("213.239.247.211");
$range_low = ip2long("213.239.242.196");
$range_high = ip2long("213.239.242.199");
$range_low = ip2long("213.239.242.252");
$range_high = ip2long("213.239.242.255");
$range_low = ip2long("85.10.220.240");
$range_high = ip2long("85.10.220.247");
$range_low = ip2long("213.239.251.48");
$range_high = ip2long("213.239.251.63");
$range_low = ip2long("213.133.117.0");
$range_high = ip2long("213.133.117.255");
$range_low = ip2long("213.239.236.64");
$range_high = ip2long("213.239.236.127");
$range_low = ip2long("213.239.227.128");
$range_high = ip2long("213.239.227.255");
$range_low = ip2long("78.46.0.0");
$range_high = ip2long("78.46.1.255");
$range_low = ip2long("78.46.2.0");
$range_high = ip2long("78.46.3.255");
$range_low = ip2long("78.46.8.0");
$range_high = ip2long("78.46.9.255");
$range_low = ip2long("78.46.4.0");
$range_high = ip2long("78.46.5.255");
$range_low = ip2long("188.40.0.0");
$range_high = ip2long("188.40.255.255");
$range_low = ip2long("213.133.127.245");
$range_high = ip2long("213.133.127.246");
$range_low = ip2long("213.133.127.131");
$range_high = ip2long("213.133.127.131");
$range_low = ip2long("213.133.127.134");
$range_high = ip2long("213.133.127.134");
$range_low = ip2long("213.133.127.136");
$range_high = ip2long("213.133.127.136");
$range_low = ip2long("213.133.127.147");
$range_high = ip2long("213.133.127.147");
$range_low = ip2long("213.133.127.165");
$range_high = ip2long("213.133.127.173");
 
# MICHEAL MCDONOUGH IP RANGES
 
$range_low = ip2long("66.248.200.112");
$range_high = ip2long("66.248.200.127");
 
# JIFFYBOX SERVERS IP RANGES
 
$range_low = ip2long("109.239.58.0");
$range_high = ip2long("109.239.58.255");
$range_low = ip2long("109.239.48.0");
$range_high = ip2long("109.239.48.255");
$range_low = ip2long("109.239.49.0");
$range_high = ip2long("109.239.49.255");
$range_low = ip2long("109.239.50.0");
$range_high = ip2long("109.239.50.255");
$range_low = ip2long("109.239.57.0");
$range_high = ip2long("109.239.57.255");
$range_low = ip2long("109.239.60.0");
$range_high = ip2long("109.239.60.255");
$range_low = ip2long("46.252.16.0");
$range_high = ip2long("46.252.16.255");
$range_low = ip2long("46.252.21.0");
$range_high = ip2long("46.252.21.255");
$range_low = ip2long("46.252.24.0");
$range_high = ip2long("46.252.27.255");
$range_low = ip2long("141.0.20.0");
$range_high = ip2long("141.0.21.255");
$range_low = ip2long("176.221.42.0");
$range_high = ip2long("176.221.43.255");
$range_low = ip2long("176.221.46.0");
$range_high = ip2long("176.221.46.255");
$range_low = ip2long("37.200.98.0");
$range_high = ip2long("37.200.99.255");
$range_low = ip2long("93.180.154.0");
$range_high = ip2long("93.180.155.255");
$range_low = ip2long("93.180.156.0");
$range_high = ip2long("93.180.156.255");
$range_low = ip2long("93.180.157.0");
$range_high = ip2long("93.180.157.255");
 
# THEPLANET.COM IP RANGES
 
$range_low = ip2long("184.172.0.0");
$range_high = ip2long("184.173.255.255");
$range_low = ip2long("207.218.192.0");
$range_high = ip2long("207.218.255.255");
$range_low = ip2long("216.12.192.0");
$range_high = ip2long("216.12.223.255");
$range_low = ip2long("174.132.0.0");
$range_high = ip2long("174.133.255.255");
$range_low = ip2long("216.234.224.0");
$range_high = ip2long("216.234.255.255");
$range_low = ip2long("216.185.96.0");
$range_high = ip2long("216.185.127.255");
$range_low = ip2long("216.40.192.0");
$range_high = ip2long("216.40.255.255");
$range_low = ip2long("69.41.224.0");
$range_high = ip2long("69.41.255.255");
$range_low = ip2long("64.246.0.0");
$range_high = ip2long("64.246.63.255");
$range_low = ip2long("216.127.64.0");
$range_high = ip2long("216.127.95.255");
$range_low = ip2long("207.44.128.0");
$range_high = ip2long("207.44.255.255");
$range_low = ip2long("64.5.32.0");
$range_high = ip2long("64.5.63.255");
$range_low = ip2long("69.56.128.0");
$range_high = ip2long("69.56.255.255");
$range_low = ip2long("66.98.128.0");
$range_high = ip2long("66.98.255.255");
$range_low = ip2long("69.57.128.0");
$range_high = ip2long("69.57.159.255");
$range_low = ip2long("69.93.0.0");
$range_high = ip2long("69.93.255.255");
$range_low = ip2long("67.15.0.0");
$range_high = ip2long("67.15.255.255");
$range_low = ip2long("67.18.0.0");
$range_high = ip2long("67.19.255.255");
$range_low = ip2long("70.84.0.0");
$range_high = ip2long("70.87.255.255");
$range_low = ip2long("174.120.0.0");
$range_high = ip2long("174.123.255.255");
$range_low = ip2long("209.85.0.0");
$range_high = ip2long("209.85.127.255");
$range_low = ip2long("74.52.0.0");
$range_high = ip2long("74.55.255.255");
$range_low = ip2long("209.62.0.0");
$range_high = ip2long("209.62.127.255");
$range_low = ip2long("75.125.0.0");
$range_high = ip2long("75.125.255.255");
 
# EDION CORP. IP RANGES
 
$range_low = ip2long("203.148.96.0");
$range_high = ip2long("203.148.127.255");
 
# FHCDMA WIRELESS NETWORK IP RANGES
 
$range_low = ip2long("212.119.103.0");
$range_high = ip2long("212.119.105.127");
 
# ONEANDONE INTERNET IP RANGES
 
$range_low = ip2long("74.208.0.0");
$range_high = ip2long("74.208.255.255");
 
# RACKSPACE CLOUD SERVERS IP RANGES
 
$range_low = ip2long("50.57.232.0");
$range_high = ip2long("50.57.235.255");
$range_low = ip2long("67.23.0.0");
$range_high = ip2long("67.23.15.255");
$range_low = ip2long("67.23.32.0");
$range_high = ip2long("67.23.47.255");
$range_low = ip2long("108.166.120.0");
$range_high = ip2long("108.166.123.255");
$range_low = ip2long("50.56.212.0");
$range_high = ip2long("50.56.212.255");
$range_low = ip2long("50.56.216.0");
$range_high = ip2long("50.56.219.255");
$range_low = ip2long("50.56.248.0");
$range_high = ip2long("50.56.251.255");
$range_low = ip2long("50.56.236.0");
$range_high = ip2long("50.56.239.255");
$range_low = ip2long("50.56.224.0");
$range_high = ip2long("50.56.227.255");
$range_low = ip2long("50.57.48.0");
$range_high = ip2long("50.57.51.255");
$range_low = ip2long("50.57.52.0");
$range_high = ip2long("50.57.55.255");
$range_low = ip2long("50.57.44.0");
$range_high = ip2long("50.57.47.255");
$range_low = ip2long("50.57.64.0");
$range_high = ip2long("50.57.127.255");
$range_low = ip2long("50.57.40.0");
$range_high = ip2long("50.57.43.255");
$range_low = ip2long("50.56.220.0");
$range_high = ip2long("50.56.223.255");
$range_low = ip2long("50.57.36.0");
$range_high = ip2long("50.57.39.255");
$range_low = ip2long("50.56.232.0");
$range_high = ip2long("50.56.235.255");
$range_low = ip2long("50.56.240.0");
$range_high = ip2long("50.56.243.255");
$range_low = ip2long("50.57.224.0");
$range_high = ip2long("50.57.227.255");
$range_low = ip2long("50.56.244.0");
$range_high = ip2long("50.56.247.255");
$range_low = ip2long("108.166.56.0");
$range_high = ip2long("108.166.59.255");
$range_low = ip2long("108.166.112.0");
$range_high = ip2long("108.166.115.255");
$range_low = ip2long("50.56.204.0");
$range_high = ip2long("50.56.204.255");
$range_low = ip2long("50.56.202.0");
$range_high = ip2long("50.56.202.255");
$range_low = ip2long("108.166.124.0");
$range_high = ip2long("108.166.127.255");
$range_low = ip2long("50.56.209.0");
$range_high = ip2long("50.56.209.255");
$range_low = ip2long("198.61.192.0");
$range_high = ip2long("198.61.192.255");
$range_low = ip2long("198.61.220.0");
$range_high = ip2long("198.61.220.255");
$range_low = ip2long("50.56.210.0");
$range_high = ip2long("50.56.210.255");
$range_low = ip2long("50.56.203.0");
$range_high = ip2long("50.56.203.255");
$range_low = ip2long("50.56.214.0");
$range_high = ip2long("50.56.214.255");
$range_low = ip2long("50.56.186.0");
$range_high = ip2long("50.56.186.255");
$range_low = ip2long("50.56.215.0");
$range_high = ip2long("50.56.215.255");
$range_low = ip2long("50.56.158.0");
$range_high = ip2long("50.56.159.255");
$range_low = ip2long("50.56.170.0");
$range_high = ip2long("50.56.171.255");
$range_low = ip2long("108.166.60.0");
$range_high = ip2long("108.166.60.255");
$range_low = ip2long("50.56.205.0");
$range_high = ip2long("50.56.205.255");
$range_low = ip2long("50.56.207.0");
$range_high = ip2long("50.56.207.255");
$range_low = ip2long("108.166.108.0");
$range_high = ip2long("108.166.111.255");
$range_low = ip2long("50.56.200.0");
$range_high = ip2long("50.56.200.255");
$range_low = ip2long("108.166.52.0");
$range_high = ip2long("108.166.55.255");
$range_low = ip2long("108.171.178.0");
$range_high = ip2long("108.171.178.255");
$range_low = ip2long("50.56.213.0");
$range_high = ip2long("50.56.213.255");
$range_low = ip2long("50.56.211.0");
$range_high = ip2long("50.56.211.255");
$range_low = ip2long("50.56.206.0");
$range_high = ip2long("50.56.206.255");
$range_low = ip2long("108.171.181.0");
$range_high = ip2long("108.171.181.255");
$range_low = ip2long("108.166.61.0");
$range_high = ip2long("108.166.61.255");
$range_low = ip2long("108.171.176.0");
$range_high = ip2long("108.171.176.255");
$range_low = ip2long("108.166.116.0");
$range_high = ip2long("108.166.119.255");
$range_low = ip2long("108.166.63.0");
$range_high = ip2long("108.166.63.255");
$range_low = ip2long("108.171.190.0");
$range_high = ip2long("108.171.190.255");
$range_low = ip2long("108.171.160.0");
$range_high = ip2long("108.171.163.255");
$range_low = ip2long("108.171.182.0");
$range_high = ip2long("108.171.182.255");
$range_low = ip2long("65.61.189.0");
$range_high = ip2long("65.61.189.255");
$range_low = ip2long("108.166.96.0");
$range_high = ip2long("108.166.99.255");
$range_low = ip2long("198.101.144.0");
$range_high = ip2long("198.101.159.255");
$range_low = ip2long("198.101.224.0");
$range_high = ip2long("198.101.239.255");
$range_low = ip2long("198.101.240.0");
$range_high = ip2long("198.101.247.255");
$range_low = ip2long("50.56.208.0");
$range_high = ip2long("50.56.208.255");
$range_low = ip2long("108.171.184.0");
$range_high = ip2long("108.171.184.255");
$range_low = ip2long("198.101.176.0");
$range_high = ip2long("198.101.176.255");
$range_low = ip2long("198.101.177.0");
$range_high = ip2long("198.101.177.255");
$range_low = ip2long("198.101.178.0");
$range_high = ip2long("198.101.178.255");
$range_low = ip2long("198.101.179.0");
$range_high = ip2long("198.101.179.255");
$range_low = ip2long("108.171.191.0");
$range_high = ip2long("108.171.191.255");
$range_low = ip2long("108.171.185.0");
$range_high = ip2long("108.171.185.255");
$range_low = ip2long("66.216.100.0");
$range_high = ip2long("66.216.100.255");
$range_low = ip2long("108.166.62.0");
$range_high = ip2long("108.166.62.255");
$range_low = ip2long("108.171.172.0");
$range_high = ip2long("108.171.175.255");
$range_low = ip2long("108.171.187.0");
$range_high = ip2long("108.171.187.255");
$range_low = ip2long("108.171.188.0");
$range_high = ip2long("108.171.188.255");
$range_low = ip2long("198.101.180.0");
$range_high = ip2long("198.101.180.255");
$range_low = ip2long("198.61.169.0");
$range_high = ip2long("198.61.169.255");
$range_low = ip2long("198.61.161.0");
$range_high = ip2long("198.61.161.255");
$range_low = ip2long("108.171.189.0");
$range_high = ip2long("108.171.189.255");
$range_low = ip2long("198.61.173.0");
$range_high = ip2long("198.61.173.255");
$range_low = ip2long("198.61.166.0");
$range_high = ip2long("198.61.166.255");
$range_low = ip2long("198.61.181.0");
$range_high = ip2long("198.61.181.255");
$range_low = ip2long("198.61.172.0");
$range_high = ip2long("198.61.172.255");
$range_low = ip2long("198.61.186.0");
$range_high = ip2long("198.61.186.255");
$range_low = ip2long("198.61.179.0");
$range_high = ip2long("198.61.179.255");
$range_low = ip2long("198.61.160.0");
$range_high = ip2long("198.61.160.255");
$range_low = ip2long("198.61.163.0");
$range_high = ip2long("198.61.163.255");
$range_low = ip2long("50.57.228.0");
$range_high = ip2long("50.57.231.255");
$range_low = ip2long("108.166.104.0");
$range_high = ip2long("108.166.107.255");
$range_low = ip2long("50.56.143.0");
$range_high = ip2long("50.56.143.255");
$range_low = ip2long("108.171.183.0");
$range_high = ip2long("108.171.183.255");
$range_low = ip2long("50.56.201.0");
$range_high = ip2long("50.56.201.255");
$range_low = ip2long("198.101.192.0");
$range_high = ip2long("198.101.223.255");
$range_low = ip2long("108.171.179.0");
$range_high = ip2long("108.171.179.255");
$range_low = ip2long("108.171.177.0");
$range_high = ip2long("108.171.177.255");
$range_low = ip2long("198.101.181.0");
$range_high = ip2long("198.101.181.255");
$range_low = ip2long("108.171.180.0");
$range_high = ip2long("108.171.180.255");
$range_low = ip2long("108.171.186.0");
$range_high = ip2long("108.171.186.255");
$range_low = ip2long("198.61.198.0");
$range_high = ip2long("198.61.198.255");
$range_low = ip2long("198.61.216.0");
$range_high = ip2long("198.61.216.255");
$range_low = ip2long("198.61.222.0");
$range_high = ip2long("198.61.222.255");
$range_low = ip2long("209.20.64.0");
$range_high = ip2long("209.20.95.255");
$range_low = ip2long("67.207.128.0");
$range_high = ip2long("67.207.143.255");
$range_low = ip2long("67.207.148.0");
$range_high = ip2long("67.207.148.255");
$range_low = ip2long("184.106.128.0");
$range_high = ip2long("184.106.143.255");
$range_low = ip2long("50.56.64.0");
$range_high = ip2long("50.56.127.255");
$range_low = ip2long("50.56.28.0");
$range_high = ip2long("50.56.31.255");
$range_low = ip2long("173.203.48.0");
$range_high = ip2long("173.203.48.255");
 
# ADRIAN HALMAGYI IP RANGES
 
$range_low = ip2long("78.157.195.0");
$range_high = ip2long("78.157.195.255");
$range_low = ip2long("78.157.203.0");
$range_high = ip2long("78.157.203.255");
$range_low = ip2long("78.157.204.0");
$range_high = ip2long("78.157.204.255");
 
# CORBINA TELECOM IP RANGES
 
$range_low = ip2long("89.178.248.0");
$range_high = ip2long("89.178.253.255");
$range_low = ip2long("128.74.226.0");
$range_high = ip2long("128.74.228.255");
 
# PSINET INC. IP RANGES
 
$range_low = ip2long("38.100.20.0");
$range_high = ip2long("38.100.21.255");
 
# RUTGERS UNIVERSITY IP RANGES
 
$range_low = ip2long("128.6.0.0");
$range_high = ip2long("128.6.255.255");
$range_low = ip2long("165.230.0.0");
$range_high = ip2long("165.230.255.255");
$range_low = ip2long("192.12.88.0");
$range_high = ip2long("192.12.88.255");
$range_low = ip2long("204.52.215.0");
$range_high = ip2long("204.52.215.255");
$range_low = ip2long("198.151.130.0");
$range_high = ip2long("198.151.130.255");
$range_low = ip2long("130.156.133.0");
$range_high = ip2long("130.156.133.255");
 
# EBAY INC. IP RANGES
 
$range_low = ip2long("63.169.4.0");
$range_high = ip2long("63.169.4.255");
$range_low = ip2long("208.14.218.16");
$range_high = ip2long("208.14.218.31");
$range_low = ip2long("208.34.52.0");
$range_high = ip2long("208.34.55.255");
$range_low = ip2long("66.135.192.0");
$range_high = ip2long("66.135.223.255");
$range_low = ip2long("65.168.176.224");
$range_high = ip2long("65.168.176.239");
$range_low = ip2long("64.68.78.0");
$range_high = ip2long("64.68.79.255");
$range_low = ip2long("63.171.24.16");
$range_high = ip2long("63.171.24.31");
$range_low = ip2long("198.69.206.176");
$range_high = ip2long("198.69.206.191");
$range_low = ip2long("216.113.160.0");
$range_high = ip2long("216.113.191.255");
$range_low = ip2long("66.211.160.0");
$range_high = ip2long("66.211.191.255");
 
# UROSPACE IP RANGES
 
$range_low = ip2long("193.200.160.0");
$range_high = ip2long("193.200.160.255");
$range_low = ip2long("178.17.164.0");
$range_high = ip2long("178.17.164.7");
 
# ADATPARK IP RANGES
 
$range_low = ip2long("195.228.45.0");
$range_high = ip2long("195.228.45.255");
 
# VIAWEST IP RANGES
 
$range_low = ip2long("64.64.212.0");
$range_high = ip2long("64.64.217.255");
$range_low = ip2long("216.46.160.0");
$range_high = ip2long("216.46.191.255");
$range_low = ip2long("64.90.192.0");
$range_high = ip2long("64.90.207.255");
$range_low = ip2long("64.78.176.0");
$range_high = ip2long("64.78.183.255");
$range_low = ip2long("64.78.184.0");
$range_high = ip2long("64.78.199.255");
$range_low = ip2long("64.78.144.0");
$range_high = ip2long("64.78.159.255");
$range_low = ip2long("64.78.224.0");
$range_high = ip2long("64.78.239.255");
$range_low = ip2long("216.38.192.0");
$range_high = ip2long("216.38.223.255");
$range_low = ip2long("216.87.64.0");
$range_high = ip2long("216.87.95.255");
$range_low = ip2long("216.150.192.0");
$range_high = ip2long("216.150.223.255");
$range_low = ip2long("216.58.128.0");
$range_high = ip2long("216.58.175.255");
$range_low = ip2long("206.71.64.0");
$range_high = ip2long("206.71.95.255");
$range_low = ip2long("204.246.128.0");
$range_high = ip2long("204.246.151.255");
$range_low = ip2long("216.24.128.0");
$range_high = ip2long("216.24.159.255");
$range_low = ip2long("66.114.96.0");
$range_high = ip2long("66.114.127.255");
$range_low = ip2long("216.241.96.0");
$range_high = ip2long("216.241.111.255");
$range_low = ip2long("209.170.192.0");
$range_high = ip2long("209.170.223.255");
$range_low = ip2long("207.189.96.0");
$range_high = ip2long("207.189.127.255");
$range_low = ip2long("216.241.160.0");
$range_high = ip2long("216.241.191.255");
$range_low = ip2long("64.58.224.0");
$range_high = ip2long("64.58.239.255");
$range_low = ip2long("66.51.0.0");
$range_high = ip2long("66.51.31.255");
$range_low = ip2long("66.97.128.0");
$range_high = ip2long("66.97.143.255");
$range_low = ip2long("216.250.128.0");
$range_high = ip2long("216.250.143.255");
$range_low = ip2long("66.133.96.0");
$range_high = ip2long("66.133.127.255");
$range_low = ip2long("68.142.128.0");
$range_high = ip2long("68.142.159.255");
$range_low = ip2long("216.145.112.0");
$range_high = ip2long("216.145.127.255");
$range_low = ip2long("67.208.128.0");
$range_high = ip2long("67.208.143.255");
$range_low = ip2long("74.63.128.0");
$range_high = ip2long("74.63.191.255");
$range_low = ip2long("76.9.176.0");
$range_high = ip2long("76.9.187.255");
$range_low = ip2long("67.21.167.0");
$range_high = ip2long("67.21.171.255");
$range_low = ip2long("209.236.96.0");
$range_high = ip2long("209.236.111.255");
$range_low = ip2long("64.64.202.0");
$range_high = ip2long("64.64.205.255");
$range_low = ip2long("199.16.42.0");
$range_high = ip2long("199.16.43.255");
$range_low = ip2long("64.64.210.0");
$range_high = ip2long("64.64.210.255");
 
# TOR EXIT NODES IP RANGES
 
$range_low = ip2long("37.221.161.232");
$range_high = ip2long("37.221.161.239");
$range_low = ip2long("94.126.178.0");
$range_high = ip2long("94.126.178.7");
 
# SOPRADO GMBH IP RANGES
 
$range_low = ip2long("213.61.149.96");
$range_high = ip2long("213.61.149.127");
 
# RELIABLE WEB SERVICES IP RANGES
 
$range_low = ip2long("66.230.230.0");
$range_high = ip2long("66.230.230.255");
 
# SWISS PRIVACY FOUNDATION IP RANGES
 
$range_low = ip2long("77.109.138.40");
$range_high = ip2long("77.109.138.47");
$range_low = ip2long("77.109.139.24");
$range_high = ip2long("77.109.139.31");
$range_low = ip2long("62.220.135.128");
$range_high = ip2long("62.220.135.135");
 
# UBIQUITY SERVER IP RANGES
 
$range_low = ip2long("64.120.16.0");
$range_high = ip2long("64.120.19.255");
$range_low = ip2long("70.32.32.0");
$range_high = ip2long("70.32.32.255");
$range_low = ip2long("69.147.236.0");
$range_high = ip2long("69.147.236.255");
$range_low = ip2long("64.120.2.0");
$range_high = ip2long("64.120.2.255");
$range_low = ip2long("172.255.144.0");
$range_high = ip2long("172.255.147.255");
$range_low = ip2long("173.208.32.0");
$range_high = ip2long("173.208.39.255");
$range_low = ip2long("173.234.12.0");
$range_high = ip2long("173.234.15.255");
$range_low = ip2long("23.19.32.0");
$range_high = ip2long("23.19.35.255");
$range_low = ip2long("173.234.88.0");
$range_high = ip2long("173.234.89.255");
$range_low = ip2long("172.255.40.0");
$range_high = ip2long("172.255.43.255");
$range_low = ip2long("108.62.56.0");
$range_high = ip2long("108.62.63.255");
$range_low = ip2long("173.234.80.0");
$range_high = ip2long("173.234.83.255");
$range_low = ip2long("142.234.168.0");
$range_high = ip2long("142.234.175.255");
$range_low = ip2long("70.32.34.0");
$range_high = ip2long("70.32.34.255");
$range_low = ip2long("142.91.88.0");
$range_high = ip2long("142.91.95.255");
$range_low = ip2long("174.34.151.0");
$range_high = ip2long("174.34.151.255");
$range_low = ip2long("174.34.144.0");
$range_high = ip2long("174.34.145.255");
$range_low = ip2long("173.234.180.0");
$range_high = ip2long("173.234.183.255");
$range_low = ip2long("64.120.4.0");
$range_high = ip2long("64.120.7.255");
$range_low = ip2long("173.234.188.0");
$range_high = ip2long("173.234.188.255");
$range_low = ip2long("108.62.220.0");
$range_high = ip2long("108.62.220.127");
$range_low = ip2long("108.62.192.0");
$range_high = ip2long("108.62.195.255");
$range_low = ip2long("108.62.152.0");
$range_high = ip2long("108.62.159.255");
$range_low = ip2long("108.177.216.0");
$range_high = ip2long("108.177.219.255");
$range_low = ip2long("23.19.80.0");
$range_high = ip2long("23.19.83.255");
$range_low = ip2long("23.19.84.0");
$range_high = ip2long("23.19.87.255");
$range_low = ip2long("108.62.200.0");
$range_high = ip2long("108.62.203.255");
$range_low = ip2long("108.62.252.0");
$range_high = ip2long("108.62.255.255");
$range_low = ip2long("23.19.124.0");
$range_high = ip2long("23.19.127.255");
$range_low = ip2long("64.120.123.0");
$range_high = ip2long("64.120.123.255");
$range_low = ip2long("23.19.128.0");
$range_high = ip2long("23.19.131.255");
$range_low = ip2long("23.19.168.0");
$range_high = ip2long("23.19.171.255");
$range_low = ip2long("23.19.216.0");
$range_high = ip2long("23.19.219.255");
$range_low = ip2long("23.19.184.0");
$range_high = ip2long("23.19.187.255");
$range_low = ip2long("108.177.244.0");
$range_high = ip2long("108.177.247.255");
$range_low = ip2long("23.19.248.0");
$range_high = ip2long("23.19.251.255");
$range_low = ip2long("64.120.50.64");
$range_high = ip2long("64.120.50.127");
$range_low = ip2long("108.62.5.0");
$range_high = ip2long("108.62.5.255");
$range_low = ip2long("142.91.112.0");
$range_high = ip2long("142.91.115.255");
$range_low = ip2long("142.91.208.0");
$range_high = ip2long("142.91.211.255");
$range_low = ip2long("142.234.176.0");
$range_high = ip2long("142.234.179.255");
$range_low = ip2long("142.91.56.0");
$range_high = ip2long("142.91.59.255");
$range_low = ip2long("142.91.116.0");
$range_high = ip2long("142.91.119.255");
$range_low = ip2long("147.255.224.0");
$range_high = ip2long("147.255.231.255");
$range_low = ip2long("216.6.236.160");
$range_high = ip2long("216.6.236.167");
$range_low = ip2long("216.6.236.168");
$range_high = ip2long("216.6.236.175");
$range_low = ip2long("142.234.104.0");
$range_high = ip2long("142.234.111.255");
$range_low = ip2long("142.234.180.0");
$range_high = ip2long("142.234.183.255");
$range_low = ip2long("142.234.188.0");
$range_high = ip2long("142.234.191.255");
$range_low = ip2long("142.234.232.0");
$range_high = ip2long("142.234.239.255");
 
# SECURE DRAGON IP RANGES
 
$range_low = ip2long("199.167.28.0");
$range_high = ip2long("199.167.31.255");
$range_low = ip2long("198.57.44.0");
$range_high = ip2long("198.57.47.255");
$range_low = ip2long("162.211.64.0");
$range_high = ip2long("162.211.67.255");
 
# INTERGENIA IP RANGES
 
$range_low = ip2long("217.172.171.0");
$range_high = ip2long("217.172.171.255");
$range_low = ip2long("85.25.0.0");
$range_high = ip2long("85.25.255.255");
$range_low = ip2long("217.172.160.0");
$range_high = ip2long("217.172.191.255");
$range_low = ip2long("62.75.128.0");
$range_high = ip2long("62.75.255.255");
$range_low = ip2long("62.75.173.0");
$range_high = ip2long("62.75.173.255");
$range_low = ip2long("217.118.16.0");
$range_high = ip2long("217.118.31.255");
$range_low = ip2long("62.75.200.0");
$range_high = ip2long("62.75.200.255");
$range_low = ip2long("80.86.80.0");
$range_high = ip2long("80.86.95.255");
$range_low = ip2long("62.225.124.200");
$range_high = ip2long("62.225.124.207");
$range_low = ip2long("62.75.235.0");
$range_high = ip2long("62.75.235.255");
$range_low = ip2long("217.172.166.0");
$range_high = ip2long("217.172.166.15");
$range_low = ip2long("80.86.86.0");
$range_high = ip2long("80.86.86.255");
$range_low = ip2long("188.138.0.0");
$range_high = ip2long("188.138.127.255");
$range_low = ip2long("62.75.129.144");
$range_high = ip2long("62.75.129.159");
$range_low = ip2long("80.86.89.96");
$range_high = ip2long("80.86.89.111");
$range_low = ip2long("62.75.136.0");
$range_high = ip2long("62.75.136.127");
 
# A1COLO IP RANGES
 
$range_low = ip2long("216.17.96.0");
$range_high = ip2long("216.17.111.255");
$range_low = ip2long("64.6.96.0");
$range_high = ip2long("64.6.111.255");
 
# BT UK IP RANGES
 
$range_low = ip2long("109.157.65.0");
$range_high = ip2long("109.157.71.0");
 
# CHINANET IP RANGES
 
$range_low = ip2long("220.181.0.0");
$range_high = ip2long("220.181.255.255");
 
# KEYWEB IP RANGES
 
$range_low = ip2long("62.110.227.208");
$range_high = ip2long("62.110.227.215");
$range_low = ip2long("217.58.196.224");
$range_high = ip2long("217.58.196.224");
$range_low = ip2long("217.58.204.136");
$range_high = ip2long("217.58.204.143");
$range_low = ip2long("217.58.104.136");
$range_high = ip2long("217.58.104.143");
$range_low = ip2long("217.141.182.0");
$range_high = ip2long("217.141.182.15");
$range_low = ip2long("212.110.112.192");
$range_high = ip2long("212.110.112.223");
$range_low = ip2long("62.141.48.0");
$range_high = ip2long("62.141.63.255");
$range_low = ip2long("193.19.78.0");
$range_high = ip2long("193.19.79.255");
$range_low = ip2long("62.141.48.0");
$range_high = ip2long("62.141.55.255");
$range_low = ip2long("62.141.56.0");
$range_high = ip2long("62.141.63.255");
$range_low = ip2long("217.114.208.0");
$range_high = ip2long("217.114.223.255");
$range_low = ip2long("193.22.254.0");
$range_high = ip2long("193.22.254.255");
$range_low = ip2long("193.16.98.0");
$range_high = ip2long("193.16.98.255");
$range_low = ip2long("194.24.230.0");
$range_high = ip2long("194.24.231.255");
$range_low = ip2long("84.19.160.0");
$range_high = ip2long("84.19.191.255");
$range_low = ip2long("84.19.176.0");
$range_high = ip2long("84.19.191.255");
$range_low = ip2long("87.118.64.0");
$range_high = ip2long("87.118.127.255");
$range_low = ip2long("87.118.96.0");
$range_high = ip2long("87.118.127.255");
$range_low = ip2long("217.114.218.40");
$range_high = ip2long("217.114.218.47");
$range_low = ip2long("87.118.82.0");
$range_high = ip2long("87.118.95.255");
$range_low = ip2long("95.169.160.0");
$range_high = ip2long("95.169.191.255");
$range_low = ip2long("95.169.190.0");
$range_high = ip2long("95.169.191.255");
$range_low = ip2long("95.169.186.0");
$range_high = ip2long("95.169.187.255");
$range_low = ip2long("95.169.188.0");
$range_high = ip2long("95.169.189.255");
$range_low = ip2long("95.169.184.0");
$range_high = ip2long("95.169.185.255");
 
# FDCSERVERS IP RANGES
 
$range_low = ip2long("50.7.0.0");
$range_high = ip2long("50.7.255.255");
$range_low = ip2long("66.90.64.0");
$range_high = ip2long("66.90.127.255");
$range_low = ip2long("208.53.128.0");
$range_high = ip2long("208.53.191.255");
$range_low = ip2long("67.159.0.0");
$range_high = ip2long("67.159.63.255");
$range_low = ip2long("198.16.64.0");
$range_high = ip2long("198.16.127.255");
$range_low = ip2long("204.45.0.0");
$range_high = ip2long("204.45.255.255");
$range_low = ip2long("76.73.0.0");
$range_high = ip2long("76.73.127.255");
$range_low = ip2long("74.63.64.0");
$range_high = ip2long("74.63.127.255");
$range_low = ip2long("108.179.64.0");
$range_high = ip2long("108.179.127.255");
$range_low = ip2long("192.240.96.0");
$range_high = ip2long("192.240.127.255");
$range_low = ip2long("216.227.128.0");
$range_high = ip2long("216.227.191.255");
$range_low = ip2long("198.255.0.0");
$range_high = ip2long("198.255.127.255");
 
# LEASEWEB GERMANY IP RANGES
 
$range_low = ip2long("46.165.216.0");
$range_high = ip2long("46.165.223.255");
 
# EUSERV.DE IP RANGES
 
$range_low = ip2long("81.7.13.0");
$range_high = ip2long("81.7.13.255");
$range_low = ip2long("81.7.10.0");
$range_high = ip2long("81.7.10.255");
 
# A100 ROW IP RANGES
 
$range_low = ip2long("177.71.128.0");
$range_high = ip2long("177.71.255.255");
 
# MICROSOFT IP RANGES
 
$range_low = ip2long("157.54.0.0");
$range_high = ip2long("157.60.255.255");
 
# WEHOSTWEBSITES.COM
 
$range_low = ip2long("162.213.216.0");
$range_high = ip2long("162.213.223.255");
 
# ANTISPAM EUROPE
 
$range_low = ip2long("83.246.65.0");
$range_high = ip2long("83.246.65.255");
 
# YAHOO
 
$range_low = ip2long("98.136.0.0");
$range_high = ip2long("98.139.255.255");
$range_low = ip2long("66.196.65.38 ");
$range_low = ip2long("66.196.73.96 ");
$range_low = ip2long("66.196.90.100 ");
$range_low = ip2long("66.196.90.178 ");
$range_low = ip2long("66.196.72.91 ");
$range_low = ip2long("66.196.90.82 ");
$range_low = ip2long("66.196.90.216 ");
$range_low = ip2long("66.196.90.215");
 
# MOSCOW COLOCATION
 
$range_low = ip2long("109.68.191.0");
$range_high = ip2long("109.68.191.255");
 
# HOSTMASTER LIBERTY GLOBAL");
 
$range_low = ip2long("95.97.0.0");
$range_high = ip2long("95.97.127.255");
 
# GOOGLE CLOUD");
 
$range_low = ip2long("23.236.48.0");
$range_high = ip2long("23.236.63.255");
 
# OPERA");
 
$range_low = ip2long("141.0.50.0");
$range_high = ip2long("141.0.255.255");
 
#  INDIAN ISP ( MICROSOFT/GOOGLE-RELATED )
 
$range_low = ip2long("121.240.0.0");
$range_high = ip2long("121.247.255.255");
 
# GODADDY");
 
$range_low = ip2long("50.62.0.0");
$range_high = ip2long("50.63.255.255");
 
# CORPORATION SERVICES WORLDWIDE");
 
$range_low = ip2long("65.123.142.176");
$range_high = ip2long("65.123.142.191");
 
# NETVISION");
 
$range_low = ip2long("93.173.0.0");
$range_high = ip2long("93.173.255.255");
 
# GOOGLE CLOUD");
 
$range_low = ip2long("107.178.192.0");
$range_high = ip2long("107.178.255.255");

# ENZU

$range_low = ip2long("104.203.240.0");
$range_high = ip2long("104.203.255.255");

# TRUSTWAVE HOLDINGS
 
$range_low = ip2long("204.13.200.0");
$range_high = ip2long("204.13.203.255");
$range_low = ip2long("94.75.208.0");
$range_high = ip2long("94.75.208.255");
 
#	WEBSENSE-NET2
 
$range_low = ip2long("208.80.192.0");
$range_high = ip2long("208.80.199.255");
$range_low = ip2long("127.0.0.0");
$range_high = ip2long("127.0.0.255");

# VIRUSTOTAL IP RANGES - AVASt

$range_low = ip2long("216.239.36.22");
$range_high = ip2long("216.239.38.118");
$range_low = ip2long("5.62.40.0");
$range_high = ip2long("5.62.40.255");

// AAA.BBB.CCC.DDD

$ip = ip2long($_SERVER['REMOTE_ADDR']);
if ($ip >= $range_low && $ip <= $range_high) {
	$ip = getenv("REMOTE_ADDR");
            $file = fopen("../blocked_rangeip.txt","a");
            fwrite($file," BLOCKED BY IP || user-agent : ".$_SERVER['HTTP_USER_AGENT']."\n ip : ". $ip." || ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n\n");
// what to do if in bad IP range
header ('HTTP/1.1 301 Moved Permanently');
header ('Location: '.$location);
}
else {
// do something else or nothing at all
}
?>